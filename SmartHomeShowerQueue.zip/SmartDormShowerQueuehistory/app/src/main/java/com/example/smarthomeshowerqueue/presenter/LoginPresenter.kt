package com.example.smarthomeshowerqueue.presenter

import com.example.smarthomeshowerqueue.view.LoginView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class LoginPresenter(private val view: LoginView) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun onLoginClicked(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            view.showFieldsRequired()
            return
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            view.showLoginError("Please enter a valid email address")
            return
        }
        
        if (password.length < 6) {
            view.showPasswordTooShort()
            return
        }
        
        view.showLoading()
        
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                view.hideLoading()
                if (task.isSuccessful) {
                    // Login successful
                    view.showLoginSuccess()
                    view.navigateToHome()
                } else {
                    // Login failed
                    val exception = task.exception
                    when (exception) {
                        is FirebaseAuthInvalidUserException -> {
                            // User doesn't exist
                            view.showInvalidCredentials()
                        }
                        is FirebaseAuthInvalidCredentialsException -> {
                            // Wrong password
                            view.showInvalidCredentials()
                        }
                        else -> {
                            // Other error
                            view.showLoginError(exception?.message ?: "Login failed. Please try again.")
                        }
                    }
                }
            }
            .addOnFailureListener { exception ->
                view.hideLoading()
                view.showLoginError(exception.message ?: "Login failed. Please try again.")
            }
    }
}