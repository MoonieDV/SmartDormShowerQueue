package com.example.smarthomeshowerqueue.model

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import com.example.smarthomeshowerqueue.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ProfileModel : Activity() {
    private lateinit var emailEditText: TextInputEditText
    private lateinit var usernameEditText: TextInputEditText
    private lateinit var fullNameEditText: TextInputEditText
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance(
        "https://smart-dorm-shower-queue-default-rtdb.asia-southeast1.firebasedatabase.app"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        emailEditText = findViewById(R.id.email)
        usernameEditText = findViewById(R.id.usernameText)
        fullNameEditText = findViewById(R.id.fullName)

        // Load user data
        loadUserProfile()

        findViewById<MaterialButton>(R.id.editProfileBtn).setOnClickListener {
            startActivity(Intent(this, EditProfileModel::class.java))
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, com.example.smarthomeshowerqueue.view.HomeActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.nav_menu -> {
                    showRightSideMenu(bottomNav)
                    true
                }
                else -> true
            }
        }
    }

    private fun showRightSideMenu(bottomNav: BottomNavigationView) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_side_menu)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.WHITE))

        val window = dialog.window
        if (window != null) {
            val params = WindowManager.LayoutParams()
            params.copyFrom(window.attributes)
            params.width = (resources.displayMetrics.widthPixels * 0.8).toInt()
            params.height = WindowManager.LayoutParams.MATCH_PARENT
            params.gravity = Gravity.END
            window.attributes = params
            window.attributes.windowAnimations = R.style.SideMenuDialogAnimation
        }

        dialog.findViewById<ImageView>(R.id.closeBtn)?.setOnClickListener {
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
        }
        dialog.findViewById<LinearLayout>(R.id.itemPrivacy)?.setOnClickListener {
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
            startActivity(Intent(this, PrivacySecurityModel::class.java))
        }
        dialog.findViewById<LinearLayout>(R.id.itemPrivacyPolicy)?.setOnClickListener {
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
            startActivity(Intent(this, PrivacyPolicyModel::class.java))
        }
        dialog.findViewById<LinearLayout>(R.id.itemTerms)?.setOnClickListener {
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
            startActivity(Intent(this, TermsConditionsModel::class.java))
        }
        dialog.findViewById<LinearLayout>(R.id.profile)?.setOnClickListener {
            // Already on profile; just close and reset highlight
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
        }
        dialog.findViewById<LinearLayout>(R.id.itemLogout)?.setOnClickListener {
            dialog.dismiss()
            bottomNav.selectedItemId = R.id.nav_home
            // Sign out from Firebase Auth
            auth.signOut()
            val intent = Intent(this, LoginModel::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
        dialog.setOnDismissListener { bottomNav.selectedItemId = R.id.nav_home }
        
        // Load and display user info in side menu
        loadUserInfoToSideMenu(dialog)
        
        dialog.show()
    }

    private fun loadUserProfile() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Set email from Firebase Auth
            emailEditText.setText(currentUser.email ?: "")
            
            // Load additional user data from Realtime Database
            val userRef: DatabaseReference = database.getReference("users").child(currentUser.uid)
            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Get username from database - this is what the user entered during registration
                        val username = snapshot.child("username").getValue(String::class.java) ?: ""
                        // fullName should be the same as username since we don't have separate firstname/lastname fields
                        val fullName = snapshot.child("fullName").getValue(String::class.java) ?: username
                        
                        // Use the actual username from database
                        usernameEditText.setText(username.ifEmpty { currentUser.email?.substringBefore("@") ?: "" })
                        // fullName should match username
                        fullNameEditText.setText(fullName.ifEmpty { username.ifEmpty { currentUser.email?.substringBefore("@") ?: "" } })
                    } else {
                        // If no data in Realtime Database, use email username as fallback
                        val emailUsername = currentUser.email?.substringBefore("@") ?: ""
                        usernameEditText.setText(emailUsername)
                        fullNameEditText.setText(emailUsername)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle error - use email username as fallback
                    val emailUsername = currentUser.email?.substringBefore("@") ?: ""
                    usernameEditText.setText(emailUsername)
                    fullNameEditText.setText(emailUsername)
                }
            })
        } else {
            // User not logged in, redirect to login
            val intent = Intent(this, LoginModel::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
    }

    private fun loadUserInfoToSideMenu(dialog: Dialog) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val profileNameTextView = dialog.findViewById<TextView>(R.id.profileName)
            val profileRoleTextView = dialog.findViewById<TextView>(R.id.profileRole)
            
            // Load user data from Realtime Database
            val userRef: DatabaseReference = database.getReference("users").child(currentUser.uid)
            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Get username from database - this is what the user entered during registration
                        val username = snapshot.child("username").getValue(String::class.java)
                        // fullName should be the same as username since we don't have separate firstname/lastname fields
                        val fullName = snapshot.child("fullName").getValue(String::class.java) ?: username
                        
                        // Use the username from database, not email username
                        val displayName = if (!fullName.isNullOrBlank()) {
                            fullName
                        } else if (!username.isNullOrBlank()) {
                            username
                        } else {
                            // Only use email username as last resort
                            currentUser.email?.substringBefore("@") ?: "User"
                        }
                        
                        profileNameTextView?.text = displayName
                        // Hide or remove the "Tenant" text
                        profileRoleTextView?.visibility = android.view.View.GONE
                    } else {
                        // If no data in database, use email username as fallback
                        val emailUsername = currentUser.email?.substringBefore("@") ?: "User"
                        profileNameTextView?.text = emailUsername
                        profileRoleTextView?.visibility = android.view.View.GONE
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Use email username as fallback
                    val emailUsername = currentUser.email?.substringBefore("@") ?: "User"
                    profileNameTextView?.text = emailUsername
                    profileRoleTextView?.visibility = android.view.View.GONE
                }
            })
        }
    }
}
