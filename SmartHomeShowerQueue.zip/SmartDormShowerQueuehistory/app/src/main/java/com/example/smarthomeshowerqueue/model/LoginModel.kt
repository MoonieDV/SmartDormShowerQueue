package com.example.smarthomeshowerqueue.model

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.graphics.Paint
import com.example.smarthomeshowerqueue.R
import com.example.smarthomeshowerqueue.presenter.LoginPresenter
import com.example.smarthomeshowerqueue.view.HomeActivity
import com.example.smarthomeshowerqueue.view.LoginView
import com.google.firebase.auth.FirebaseAuth

class LoginModel : Activity(), LoginView {
    private lateinit var presenter: LoginPresenter
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Check if user is already logged in
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // User is already logged in, go to home
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
            return
        }
        
        setContentView(R.layout.login_activity)
        var usernameText = findViewById<EditText>(R.id.usernameText)
        var passwordText = findViewById<EditText>(R.id.passwordText)
        var loginBtn = findViewById<Button>(R.id.loginBtn)
        presenter = LoginPresenter(this)

        loginBtn.setOnClickListener{
            val user = usernameText.text.toString()
            val pass = passwordText.text.toString()
            presenter.onLoginClicked(user, pass)
        }

        val registerHere = findViewById<android.widget.TextView>(R.id.registerHere)
        registerHere.paintFlags = registerHere.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        registerHere.setOnClickListener {
            val intent = Intent(this, RegisterModel::class.java)
            startActivity(intent)
        }

        val forgotPassword = findViewById<android.widget.TextView>(R.id.forgotPassword)
        forgotPassword.paintFlags = forgotPassword.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        forgotPassword.setOnClickListener {
            val intent = Intent(this, ForgotPasswordModel::class.java)
            startActivity(intent)
        }
    }

    override fun showLoginSuccess() {
        Toast.makeText(this, "Successfully Login", Toast.LENGTH_SHORT).show()
    }

    override fun showPasswordTooShort() {
        Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
    }

    override fun showFieldsRequired() {
        Toast.makeText(this, "Please Fill out the Details needed.", Toast.LENGTH_SHORT).show()
    }

    override fun showLoginError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun showInvalidCredentials() {
        Toast.makeText(this, "Invalid email or password. Please check your credentials or register if you don't have an account.", Toast.LENGTH_LONG).show()
    }

    override fun showLoading() {
        // You can add a progress dialog here if needed
    }

    override fun hideLoading() {
        // Hide progress dialog if added
    }

    override fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}