package com.example.smarthomeshowerqueue.view

class LoginActivity {
}