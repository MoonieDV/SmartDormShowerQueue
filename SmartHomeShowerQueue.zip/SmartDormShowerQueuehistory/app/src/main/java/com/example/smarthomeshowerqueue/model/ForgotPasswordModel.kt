package com.example.smarthomeshowerqueue.model

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.example.smarthomeshowerqueue.R
import com.example.smarthomeshowerqueue.presenter.ForgotPasswordPresenter
import com.example.smarthomeshowerqueue.view.ForgotPasswordView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class ForgotPasswordModel : Activity(), ForgotPasswordView {
    private lateinit var presenter: ForgotPasswordPresenter
    private lateinit var emailEditText: TextInputEditText
    private lateinit var resetPasswordBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        presenter = ForgotPasswordPresenter(this)
        
        emailEditText = findViewById(R.id.email)
        resetPasswordBtn = findViewById(R.id.resetPasswordBtn)

        resetPasswordBtn.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            presenter.onResetPasswordClicked(email)
        }

        val signInLink = findViewById<TextView>(R.id.signInLink)
        signInLink.setOnClickListener {
            val intent = Intent(this, LoginModel::class.java)
            startActivity(intent)
            finish()
        }
    }

    override fun showResetEmailSent() {
        Toast.makeText(this, "Password reset email sent! Please check your email inbox.", Toast.LENGTH_LONG).show()
        // Optionally navigate back to login
        val intent = Intent(this, LoginModel::class.java)
        startActivity(intent)
        finish()
    }

    override fun showEmailRequired() {
        Toast.makeText(this, "Please enter your email address", Toast.LENGTH_SHORT).show()
    }

    override fun showInvalidEmail() {
        Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
    }

    override fun showEmailNotRegistered() {
        Toast.makeText(this, "This email is not registered. Please register first or check your email address.", Toast.LENGTH_LONG).show()
    }

    override fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun showLoading() {
        resetPasswordBtn.isEnabled = false
        // You can add a progress dialog here if needed
    }

    override fun hideLoading() {
        resetPasswordBtn.isEnabled = true
        // Hide progress dialog if added
    }
}
