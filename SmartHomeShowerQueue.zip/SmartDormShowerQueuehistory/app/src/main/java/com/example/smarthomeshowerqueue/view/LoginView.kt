package com.example.smarthomeshowerqueue.view

interface LoginView {
    fun showLoginSuccess()
    fun showPasswordTooShort()
    fun showFieldsRequired()
    fun showLoginError(message: String)
    fun showInvalidCredentials()
    fun showLoading()
    fun hideLoading()
    fun navigateToHome()
}
