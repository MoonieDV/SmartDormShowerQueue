package com.example.smarthomeshowerqueue.presenter

import com.example.smarthomeshowerqueue.view.ForgotPasswordView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class ForgotPasswordPresenter(private val view: ForgotPasswordView) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun onResetPasswordClicked(email: String) {
        if (email.isBlank()) {
            view.showEmailRequired()
            return
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            view.showInvalidEmail()
            return
        }
        
        view.showLoading()
        
        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                view.hideLoading()
                if (task.isSuccessful) {
                    // Password reset email sent successfully
                    view.showResetEmailSent()
                } else {
                    // Failed to send reset email
                    val exception = task.exception
                    when (exception) {
                        is FirebaseAuthInvalidUserException -> {
                            // Email doesn't exist in the system
                            view.showEmailNotRegistered()
                        }
                        else -> {
                            // Other error
                            view.showError(exception?.message ?: "Failed to send reset email. Please try again.")
                        }
                    }
                }
            }
            .addOnFailureListener { exception ->
                view.hideLoading()
                view.showError(exception.message ?: "Failed to send reset email. Please try again.")
            }
    }
}

