package com.example.smarthomeshowerqueue.presenter

import com.example.smarthomeshowerqueue.view.RegisterView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.database.FirebaseDatabase

class RegisterPresenter(private val view: RegisterView) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance(
        "https://smart-dorm-shower-queue-default-rtdb.asia-southeast1.firebasedatabase.app"
    )

    fun onRegisterClicked(email: String, password: String, username: String) {
        if (email.isBlank() || password.isBlank() || username.isBlank()) {
            view.showFieldsRequired()
            return
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            view.showInvalidEmail()
            return
        }
        
        if (password.length < 6) {
            view.showPasswordTooShort()
            return
        }
        
        view.showLoading()
        
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Registration successful - save user profile to Realtime Database
                    val user = auth.currentUser
                    if (user != null) {
                        val userRef = database.getReference("users").child(user.uid)
                        val userData = hashMapOf(
                            "email" to email,
                            "username" to username,
                            "fullName" to username // Using username as fullName initially
                        )
                        
                        userRef.setValue(userData)
                            .addOnCompleteListener {
                                view.hideLoading()
                                if (it.isSuccessful) {
                                    view.showRegisterSuccess()
                                    view.navigateToLogin()
                                } else {
                                    view.showRegisterError("Registration successful but failed to save profile. Please try logging in.")
                                }
                            }
                            .addOnFailureListener {
                                view.hideLoading()
                                view.showRegisterError("Registration successful but failed to save profile. Please try logging in.")
                            }
                    } else {
                        view.hideLoading()
                        view.showRegisterError("Registration failed. Please try again.")
                    }
                } else {
                    view.hideLoading()
                    // Registration failed
                    val exception = task.exception
                    when (exception) {
                        is FirebaseAuthUserCollisionException -> {
                            // Email already exists
                            view.showEmailAlreadyExists()
                        }
                        else -> {
                            // Other error
                            view.showRegisterError(exception?.message ?: "Registration failed. Please try again.")
                        }
                    }
                }
            }
            .addOnFailureListener { exception ->
                view.hideLoading()
                view.showRegisterError(exception.message ?: "Registration failed. Please try again.")
            }
    }
}