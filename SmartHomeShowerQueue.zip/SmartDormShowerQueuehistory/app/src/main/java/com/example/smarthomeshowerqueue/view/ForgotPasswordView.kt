package com.example.smarthomeshowerqueue.view

interface ForgotPasswordView {
    fun showResetEmailSent()
    fun showEmailRequired()
    fun showInvalidEmail()
    fun showEmailNotRegistered()
    fun showError(message: String)
    fun showLoading()
    fun hideLoading()
}

