package com.example.smarthomeshowerqueue.model

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.smarthomeshowerqueue.R
import com.example.smarthomeshowerqueue.presenter.RegisterPresenter
import com.example.smarthomeshowerqueue.view.RegisterView
import com.google.android.material.textfield.TextInputEditText

class RegisterModel : Activity(), RegisterView {
    private lateinit var presenter: RegisterPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        var emailText = findViewById<TextInputEditText>(R.id.email)
        var passwordText = findViewById<TextInputEditText>(R.id.passwordText)
        var confirmPasswordText = findViewById<TextInputEditText>(R.id.confirmPassword)
        var loginBtn = findViewById<Button>(R.id.registerBtn)
        presenter = RegisterPresenter(this)

        val signInLink = findViewById<android.widget.TextView>(R.id.signInLink)
        signInLink.setOnClickListener {
            val intent = Intent(this, LoginModel::class.java)
            startActivity(intent)
            finish()
        }

        loginBtn.setOnClickListener{
            val email = emailText.text.toString().trim()
            val username = findViewById<TextInputEditText>(R.id.usernameText).text.toString().trim()
            val pass = passwordText.text.toString()
            val confirmPass = confirmPasswordText.text.toString()
            
            // Validate password confirmation
            if (pass != confirmPass) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            if (username.isBlank()) {
                Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            presenter.onRegisterClicked(email, pass, username)
        }
    }

    override fun showRegisterSuccess() {
        Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_SHORT).show()
    }

    override fun showPasswordTooShort() {
        Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
    }

    override fun showFieldsRequired() {
        Toast.makeText(this, "Please Fill out the Details needed.", Toast.LENGTH_SHORT).show()
    }

    override fun showRegisterError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun showEmailAlreadyExists() {
        Toast.makeText(this, "This email is already registered. Please use a different email or try logging in.", Toast.LENGTH_LONG).show()
    }

    override fun showInvalidEmail() {
        Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
    }

    override fun showLoading() {
        // You can add a progress dialog here if needed
    }

    override fun hideLoading() {
        // Hide progress dialog if added
    }

    override fun navigateToLogin() {
        val intent = Intent(this, LoginModel::class.java)
        startActivity(intent)
        finish()
    }
}