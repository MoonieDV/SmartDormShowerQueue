package com.example.smarthomeshowerqueue.view

interface RegisterView {
    fun showRegisterSuccess()
    fun showPasswordTooShort()
    fun showFieldsRequired()
    fun showRegisterError(message: String)
    fun showEmailAlreadyExists()
    fun showInvalidEmail()
    fun showLoading()
    fun hideLoading()
    fun navigateToLogin()
}